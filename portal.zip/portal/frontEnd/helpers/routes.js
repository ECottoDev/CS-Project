/**
* routes.js
*
* @author Edwin Cotto <cottosoftwaredevelopment@gmail.com>
* @copyright Edwin Cotto, All rights reserved.
*
* @version 2024-March-11 initial version
*/
export const routes = {
    HOME_VIEW: '#/home',
    sec_view: '#/second',
}
