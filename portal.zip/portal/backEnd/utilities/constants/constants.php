<?php

/**
* constants.js
*
* @author Edwin Cotto <cottosoftwaredevelopment@gmail.com>>
* @copyright Edwin Cotto, All rights reserved.
*
* @version 2024-March-10 initial version
*/


require_once __DIR__ . DIRECTORY_SEPARATOR . 'httpConstants.php';
